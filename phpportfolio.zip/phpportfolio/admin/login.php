<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <!-- bootstrap and font awesome cdn link -->
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

    <!-- google font cdn -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">

    <!--custom css link-->
    <link rel="stylesheet" type="text/css" href="assets/css/login_css.css">
</head>
<body>
    <div class="wrapper">
        <div class="logo">
            <img src="assets/img/admin.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            Admin
        </div>
        <form class="p-3 mt-3" method="post" action="loginvalidation.php">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="email" name="useremail" id="useremail" placeholder="Email id" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <input type="submit" name="submit" class="btn mt-3" value="login">
            <button class="btn mt-3" id="cancel">cancel</button>
        </form>
        
    </div>
	
	
    <!-- custom js link -->

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</body>
</html>